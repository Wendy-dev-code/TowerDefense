#ifndef GREENTOWER_H
#define GREENTOWER_H

#include "towerparent.h"
#include<QPoint>
//绿色炮塔类
class GreenTower : public TowerParent
{
protected:

public:
    GreenTower(QPoint pos,QPoint upleftpos, int Fwidth = 80, int Fheight = 80);
};

#endif // GREENTOWER_H
