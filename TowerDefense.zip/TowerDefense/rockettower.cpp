#include "rockettower.h"

//火箭防御塔函数实现
RocketTower::RocketTower(QPoint pos,QPoint upleftpos, int Fwidth, int Fheight)
{
    //初始化成员变量，这里不能用初始化列表
    _pos.setX(pos.x());
    _pos.setY(pos.y());
    B_sprite = QString(":/image/tower2.jpg");
    width = Fwidth, height = Fheight;
    _upleftpos.setX(upleftpos.x());
    _upleftpos.setY(upleftpos.y());
    Range = 260;    //射程
    BullPath = QString(":/image/Shells2.png");
    bullwidth = 40, bullheight = 40;           //子弹大小

    attack = 80;    //攻击

    ExplRangeWidth = 75;    //爆炸效果宽高
    ExplRangeHeight = ExplRangeWidth;
}
