/********************************************************************************
** Form generated from reading UI file 'startwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STARTWINDOW_H
#define UI_STARTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StartFrom
{
public:
    QLabel *label;
    QPushButton *pushButton_2;

    void setupUi(QWidget *StartFrom)
    {
        if (StartFrom->objectName().isEmpty())
            StartFrom->setObjectName(QString::fromUtf8("StartFrom"));
        StartFrom->resize(640, 480);
        label = new QLabel(StartFrom);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(130, 20, 441, 91));
        QFont font;
        font.setFamily(QString::fromUtf8("\347\253\231\351\205\267\351\253\230\347\253\257\351\273\221"));
        font.setPointSize(36);
        label->setFont(font);
        pushButton_2 = new QPushButton(StartFrom);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(250, 220, 141, 61));

        retranslateUi(StartFrom);

        QMetaObject::connectSlotsByName(StartFrom);
    } // setupUi

    void retranslateUi(QWidget *StartFrom)
    {
        StartFrom->setWindowTitle(QCoreApplication::translate("StartFrom", "Form", nullptr));
        label->setText(QCoreApplication::translate("StartFrom", "Tower Defense", nullptr));
        pushButton_2->setText(QCoreApplication::translate("StartFrom", "START", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StartFrom: public Ui_StartFrom {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STARTWINDOW_H
