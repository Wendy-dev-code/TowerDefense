#ifndef MYWINDOW_H
#define MYWINDOW_H
#include<QWidget>
#include<QMainWindow>
#include"tower.h"
#include<QList>
#include<QObject>
#include"object.h"
#include"object1.h"
class MyWindow:public QMainWindow
{
    Q_OBJECT
public:
    explicit MyWindow(QWidget *parent=nullptr);
    void paintEvent(QPaintEvent *);
    void set_tower();
    void addobject();
    void updatescene();
private:
    QList<Tower*>tower_list;
    QList<Object*>object_list;
    QList<Object1*>object1_list;
signals:
   char chooseBack();

};

#endif // MYWINDOW_H
