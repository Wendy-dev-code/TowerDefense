#include "startwindow.h"
#include "ui_startwindow.h"
#include "mainwindow.h"

StartFrom::StartFrom(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StartFrom)
{
    ui->setupUi(this);
    setWindowTitle("开始界面");
    QPushButton* btnarr= {ui->pushButton_2};
        connect(btnarr, &QPushButton::clicked, [=]() //监听所有按钮点击
        {
            MainWindow *mainwindow = new MainWindow(); //向游戏类中传入对应关卡编号
            mainwindow->show();     //显示窗口
        });

}

StartFrom::~StartFrom()
{
    delete ui;
}
