#include "mywindow.h"
#include"mybotton.h"
#include<QPainter>
#include<QTimer>
#include"object1.h"
MyWindow::MyWindow(QWidget *parent):QMainWindow(parent)
{
     this->setFixedSize(1000,600);
    MyBotton *back_btn = new MyBotton(":/button.png");
    back_btn->setParent(this);
    back_btn->move(40,40);
    MyBotton *setTower =new MyBotton(":/button.png");
    setTower->setParent(this);
    setTower->move(500,500);
    connect(setTower,&MyBotton::clicked,this,&MyWindow::addobject);
    connect(back_btn,&MyBotton::clicked,this,[=](){
        emit chooseBack();
    });
    QTimer *timer=new QTimer(this);
    connect(timer,&QTimer::timeout,this,&MyWindow::updatescene);//每10秒更新一次
            timer->start(10);
    MyBotton *menuBtn=new MyBotton(":/button.png");
    menuBtn->setParent(this);
    menuBtn->move(400,300);

}
void MyWindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
    foreach(Tower *tower,tower_list)
        tower->draw(&painter);
    foreach(Object *object1,object_list)
        object1->draw(&painter);
    foreach(Object1 *object2,object1_list)
        object2->draw(&painter);

}
void MyWindow::set_tower(){
    Tower *a_new_tower =new Tower(QPoint(500,200),":/tower1.png");
    tower_list.push_back(a_new_tower);
    update();
}
void MyWindow::addobject(){
    Object1 *object1=new Object1(QPoint(100,200),QPoint(700,200),":/tower1.png");
    object1_list.push_back(object1);
    update();/*
    Object *object=new Object(QPoint(100,100),QPoint(400,400),":/tower.jpg");
    object_list.push_back(object);
    object->move();
    update();*/
}
void MyWindow::updatescene(){
    //addobject();
    foreach(Object1 *object1,object1_list)
        object1->move();
    update();
}
