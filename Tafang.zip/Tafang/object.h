#ifndef OBJECT_H
#define OBJECT_H
#include<QPoint>
#include<QPixmap>
#include<QPainter>
#include<QPropertyAnimation>
#include<QObject>
class Object:public QObject
{
    Q_OBJECT
    Q_PROPERTY(QPoint currentpos READ getCurrentpos WRITE setCurrentpos)//必须要有这两个函数才能对他进行操作
public:
    Object(QPoint startpos,QPoint targetpos,QString filename);
    void draw(QPainter *painter);
    void move();
    QPoint getCurrentpos();
    void setCurrentpos(QPoint pos);
private:
    QPoint startpos;
    QPoint targetpos;
    QPoint currentpos;
    QPixmap pixmap;
signals:
};

#endif // OBJECT_H
