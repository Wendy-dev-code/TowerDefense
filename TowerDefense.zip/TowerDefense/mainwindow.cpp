#include "mainwindow.h"
#include <QDebug>
#include "struct.h"       //选择框按钮全局结构
#include <cmath>               //数学
#include "greentower.h"        //绿色防御塔类
#include "firetower.h"         //火防御塔类
#include "rockettower.h"        //光炮防御塔类
#include "startower.h"          //大炮防御塔类
#include <QPushButton>
#include<QPoint>
#include <QMediaPlayer>
#include<QApplication>
//鼠标点击区域宏
#define MouClickRegion(X, Width, Y, Height)     \
(ev->x() >= (X) && ev->x() <= (X) + (Width) &&  \
ev->y() >= (Y) && ev->y() <= (Y) + (Height))

MainWindow::MainWindow()
{
    //设置固定窗口大小
    setFixedSize(1040, 640);
    //设置标题
    setWindowTitle("游戏界面");



    QTimer* timer2 = new QTimer(this);      //用于插入怪物定时器
    timer2->start(2000);
    connect(timer2,&QTimer::timeout,[=]()
    {
            //设置路径点
            QPoint* Waypoint1[] = {new QPoint(280, 200), new QPoint(40, 200), new QPoint(40, 480),new QPoint(720,480),new QPoint(720,320),new QPoint(home->x(), home->y())};
            QPoint startpoint;
            startpoint.setX(280);
            startpoint.setY(0);
            int PathLength=sizeof(Waypoint1)/sizeof(QPoint*);
            monstermove(Waypoint1, startpoint, PathLength);
 });

    QLabel *lifelable = new QLabel(this);
    lifelable->setGeometry(20, 100, 220, 40);
    lifelable->setFont(QFont("微软雅黑", 20));
    lifelable->setText(QString("生命：%1").arg(life));

    moneylb->move(20, 40);       //位置
    setStyleSheet("color:white");   //设置颜色
    moneylb->setFont(QFont("微软雅黑", 20));             //设置金钱标签属性
    moneylb->setText(QString("金钱：%1").arg(money));    //显示金钱信息

    //定时器每时每刻执行防御塔父类数组的活动函数
    QTimer* timer = new QTimer(this);
    timer->start(120);

    connect(timer,&QTimer::timeout,[=]()
    {
        //防御塔寻找目标怪物的规律：找到最后一个怪物作为目标，目标丢失后找再继续找最后一个目标
        for (auto tw : tower_list)      //遍历防御塔
        {
            if (!tw->GetAimsMonster())   //目标怪物为空时从后往前遍历怪物数组寻找目标怪物
            {
                for(int i = enemy_list.size() - 1; i >= 0; i--){
                    //这里以防御塔中心点和怪物中心点判断
                    int _distance;
                    _distance=distance(QPoint(tw->Getpos().x(), tw->Getpos().y()),QPoint(enemy_list.at(i)->Getmpos().x() + (enemy_list.at(i)->GetWidth() >> 1),
                                                                                                          enemy_list.at(i)->Getmpos().y()+ (enemy_list.at(i)->GetHeight() >> 1)));
                    if (_distance <= tw->GetRange())
                    {
                        tw->SetAimsMonster(enemy_list.at(i));    //设置防御塔的目标怪物
                    }
                }
            }


            else if(distance(QPoint(tw->Getpos().x(),tw->Getpos().y()),QPoint(tw->GetAimsMonster()->Getmpos().x() + (tw->GetAimsMonster()->GetWidth() >> 1),
                                                                                                          tw->GetAimsMonster()->Getmpos().y()+ (tw->GetAimsMonster()->GetHeight() >> 1)))<= tw->GetRange()){
                     tw->InterBullet();           //拥有目标时一直创建子弹

                }

            if (tw->GetAimsMonster())    //目标怪物不为空
                if (distance(QPoint(tw->Getupleftpos().x() + 40, tw->Getupleftpos().y()+ 40),QPoint(tw->GetAimsMonster()->Getmpos().x() + (tw->GetAimsMonster()->GetWidth() >> 1),
                                                                                                              tw->GetAimsMonster()->Getmpos().y()+ (tw->GetAimsMonster()->GetHeight() >> 1)))> tw->GetRange())
                        tw->SetAimsMonster(NULL);     //超过距离将目标怪物设为空
        }

        //防御塔子弹移动
        for (auto defei : tower_list)
            defei->BulletMove();

        //怪物移动
        for (auto Moni = enemy_list.begin(); Moni != enemy_list.end(); Moni++)
            if((*Moni)->Move()) //怪物走到终点
            {
                delete *Moni;
                enemy_list.erase(Moni);         //怪物走到终点则删除这个怪物

                life--;
                lifelable->setText(QString("生命：%1").arg(life));

                if (life <= 0) {
                  gamewin=false;
                  gameend=true;
                }

                break;
            }

        //判断子弹击中怪物
        for (auto defei : tower_list)  //防御塔
        {
            auto &tbullvec = defei->GetBulletVec();    //临时存储子弹
            for (auto bullit = tbullvec.begin(); bullit != tbullvec.end(); bullit++)    //子弹
                for (auto monit = enemy_list.begin(); monit != enemy_list.end(); monit++)//怪物
                    if ((*bullit)->GetX() + (defei->GetBulletWidth() >> 1) >= (*monit)->Getmpos().x() && (*bullit)->GetX() <= (*monit)->Getmpos().x() + (*monit)->GetWidth() &&
                       (*bullit)->GetY() + (defei->GetBulletHeight() >> 1) >= (*monit)->Getmpos().y() && (*bullit)->GetY() <= (*monit)->Getmpos().y() + (*monit)->GetHeight())
                    {   //击中怪物时
                        tbullvec.erase(bullit);     //删除子弹

                        (*monit)->SetHealth((*monit)->GetHealth() - defei->GetAttack());

                        //将击中的怪物中心的坐标插入到爆炸效果数组
                        ExploEffectCoor.push_back(new ExploStr(QPoint((*monit)->Getmpos().x() + ((*monit)->GetWidth() >> 1), (*monit)->Getmpos().y() + ((*monit)->GetHeight() >> 1)),
                                                                defei->GetExplRangeWidth(), defei->GetExplRangeHeight()));

                        if ((*monit)->GetHealth() <= 0) //生命值为空时
                        {
                            //判断一下其他防御塔的目标怪物是否和当前防御塔消灭的怪物重复，如果重复，则将那一个防御塔的目标怪物也设为空
                            for (auto defei2 : tower_list)
                                if (defei2->GetAimsMonster() == *monit)
                                    defei2->SetAimsMonster(NULL);

                            enemy_list.erase(monit);    //删除怪物
                            QMediaPlayer * player = new QMediaPlayer;
                            player->setMedia(QUrl("qrc:/image/erase.mp3"));
                            player->setVolume(10);
                            player->play();
                            money += RewardMoney;       //击败怪物增加金钱
                            moneylb->setText(QString("金钱：%1").arg(money));//刷新标签
                        }

                        //这里不能将防御塔目标怪物设为空，因为防御塔的子弹攻击到的怪物不一定是该防御塔的目标怪物
                        goto L1;
                    }
            L1:;
        }

        //显示爆炸效果
        for (auto expli = ExploEffectCoor.begin(); expli != ExploEffectCoor.end(); expli++)
        {
            if((*expli)->index >= 8)           //爆炸效果显示完后将该效果从数组中删除
            {
                ExploEffectCoor.erase(expli);
                break;
            }

            (*expli)->index++;                 //将要显示的图片的序号++
        }

        update();   //绘图

    });
    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl("qrc:/image/dayu.mp3"));
    player->setVolume(30);
    player->play();
}
bool MainWindow::canbuytower(int money)
{
    if (this->money - money < 0) return true; //判断金钱是否足够
    this->money -= money; //扣除金钱
    moneylb->setText(QString("金钱：%1").arg(this->money)); //刷新标签文本
    return false;
}

void MainWindow::monstermove(QPoint** Waypoint1, QPoint startpoint, int PathLength)
{

    QPoint** waypoint=Waypoint1;
    if(counter >= 1 && counter <= 20)
    {
       enemy_list.push_back(new Enemy(waypoint, PathLength,QPoint(startpoint.x(), startpoint.y()), 1)); //第几条路径、第几个起始点、怪物编号
    }
    else if(counter > 20 && counter <= 45)
    {
        enemy_list.push_back(new Enemy(waypoint, PathLength,QPoint(startpoint.x(), startpoint.y()), 2));
    }
    if (counter > 45 && enemy_list.empty()){
        gamewin=true;
    }
    counter++;
    update();
}

//画出选择框
void MainWindow::DrawSelectionBox(QPainter& painter)
{
    //显示选择框
    if (!SelBox->GetDisplay())
        return;

   //画出选择框
    painter.drawPixmap(SelBox->GetX(), SelBox->GetY(), SelBox->GetWidth(), SelBox->GetHeight(),
        QPixmap(SelBox->GetImgPath()));

    //画出子按钮
    Subbtn *ASubBut = SelBox->GetSelSubBut();    //接收子按钮结构数组
    for (int i = 0; i < 4; i++)
        painter.drawPixmap(ASubBut[i].SubX, ASubBut[i].SubY, ASubBut[i].SubWidth, ASubBut[i].SubHeight,
            QPixmap(ASubBut[i].SubImgPath));

    painter.setPen(QPen(Qt::yellow, 6, Qt::SolidLine));     //设置画笔
    painter.drawRect(QRect(SelBox->GetX() + 95, SelBox->GetY() + 95, 80, 80));
}

//画出防御塔
void MainWindow::DrawDefenseTower(QPainter& painter)
{
    //画出防御塔
    for (auto defei : tower_list)  //遍历防御塔数组
    {
        //画出底座
        painter.drawPixmap(defei->Getupleftpos().x(), defei->Getupleftpos().y(), 80, 80, QPixmap(defei->GetImgPath()));

        //画出所有防御塔的攻击范围
        painter.drawEllipse(QPoint(defei->Getupleftpos().x() + 40, defei->Getupleftpos().y() + 40), defei->GetRange(), defei->GetRange());

        //画出所有防御塔子弹
        for (auto bulli : defei->GetBulletVec())
       painter.drawPixmap(bulli->bullpos.x(), bulli->bullpos.y(), defei->GetBulletWidth(), defei->GetBulletHeight(),QPixmap(defei->GetBulletPath()));
    }
}

//画出怪物
void MainWindow::DrawMonster(QPainter& painter)
{
    for (auto moni : enemy_list)//画出怪物
        painter.drawPixmap(moni->Getmpos().x(), moni->Getmpos().y(), moni->GetWidth(), moni->GetHeight(), QPixmap(moni->GetImgPath()));
}

//画出防御塔和升级按钮
void MainWindow::Drawupgrade(QPainter& painter)
{
    //根据条件画出防御塔攻击范围和升级按钮
    for (auto defei : tower_list)
        if(defei->Getupleftpos().x() == DisplayRangeX && defei->Getupleftpos().y() == DisplayRangeY && DisplayRange)
        {   //画出防御塔攻击范围
            painter.setPen(QPen(Qt::red));  //使用红色画出范围
            painter.drawEllipse(QPoint(DisplayRangeX + 40, DisplayRangeY + 40), defei->GetRange(), defei->GetRange());
            painter.drawPixmap(DisplayRangeX + 10, DisplayRangeY - 80, 60, 60, QPixmap(":/image/UpgradeBut1.png"));
        }
}

//画出爆炸效果
void MainWindow::DrawExplosion(QPainter& painter)
{
    //显示所有爆炸效果
    for (auto expli : ExploEffectCoor)
            painter.drawPixmap(expli->pos.x() - (expli->ExplRangeWidth >> 1), expli->pos.y()- (expli->ExplRangeHeight >> 1),
                expli->ExplRangeWidth, expli->ExplRangeHeight, QPixmap(QString(":/image/ExplosionEffect%1.png").arg(expli->index)));
}

//绘图事件
void MainWindow::paintEvent(QPaintEvent *)
{

    if(gamewin||gameend){
        QString text = gameend ? "Defeat" : "Victory";
        QPainter painter(this);
        painter.setPen(QPen(Qt::red));
        painter.setFont(QFont("Arial",30));
        painter.drawText(rect(), Qt::AlignCenter, text);
        return;
    }
    QPainter painter(this);     //创建画家类
    painter.setRenderHint(QPainter::Antialiasing);    //设置抗锯齿
    QPixmap pixmap(":/image/map1.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
    addtowerpit();
    QPixmap fix(":/image/GrassBlock.png");
    painter.drawPixmap(20,160, 150, 45,fix);
    DrawDefenseTower(painter);  //画出防御塔和子弹
    DrawMonster(painter);       //画出怪物
    Drawupgrade(painter);//画出攻击范围和升级按钮
    DrawExplosion(painter);     //画出爆炸效果
    DrawSelectionBox(painter);  //画出选择框
}

//鼠标点击事件
void MainWindow::mousePressEvent(QMouseEvent *ev)
{
   /* if (ev->button() != Qt::LeftButton)
        return;*/
        //判断升级按钮的点击
        if (DisplayRange)
        {
            if (MouClickRegion(DisplayRangeX + 10, 60 , DisplayRangeY - 80, 60))
            {
                //设置防御塔宽高，攻击力，微调坐标

                for (auto detw : tower_list)
                    if (detw->Getupleftpos().x() == DisplayRangeX && detw->Getupleftpos().y()== DisplayRangeY && DisplayRange)
                    {
                        if (canbuytower(200)) return;        //升级防御塔需要花费200

                        detw->SetAttack(detw->GetAttack() + 20);          //每次升级防御塔攻击力+20
                        detw->SetWidthHeight(detw->GetWidth() + 12, detw->GetHeight() + 6);   //防御塔宽高增加
                        detw->Setpos(QPoint(detw->Getpos().x() - 6, detw->Getpos().y() - 3)); //调整防御塔坐标
                        detw->SetAimsMonster(NULL);                        //将防御塔目标设为空
                        detw->SetRange() += 14;                            //设置防御塔的攻击范围
                        detw->SetExplRangeWidthHeight(detw->GetExplRangeWidth() + 5, detw->GetExplRangeHeight() + 5); //设置防御塔攻击怪物所产生的爆炸效果宽高
                       detw->SetBulletWidthHeight(detw->GetBulletWidth() + 5, detw->GetBulletHeight() + 5);          //设置子弹宽高
                        break;
                    }

                SelBox->SetDisplay(false);      //取消显示新建防御塔框
                DisplayRange = false;           //取消显示自己
                update();
                return;
            }
        }
    //判断选择框四个子按钮的点击
    Subbtn *ASubBut = SelBox->GetSelSubBut();
    for (int i = 0; i < 4; i++)
        if (MouClickRegion(ASubBut[i].SubX, ASubBut[i].SubWidth, ASubBut[i].SubY, ASubBut[i].SubHeight) && SelBox->GetDisplay())
        {
            SelBox->SetDisplay(false);      //取消显示选择框

            //根据点击的不同的按钮，将防御塔子类插入到防御塔父类数组
            switch (i)
            {
            case 0: //绿塔
                if (canbuytower(100)) return;    //扣除金钱
               tower_list.push_back(new GreenTower(QPoint(SelBox->GetX() + 110, SelBox->GetY() + 112), QPoint(SelBox->GetX() + 95, SelBox->GetY() + 95), 72, 46));
                break;
            case 1: //火塔
                if (canbuytower(180)) return;
                tower_list.push_back(new FireTower(QPoint(SelBox->GetX() + 110, SelBox->GetY() + 112),QPoint(SelBox->GetX() + 95, SelBox->GetY() + 95 ),72, 46));
                break;
            case 2: //火箭塔
                if (canbuytower(280)) return;
                tower_list.push_back(new RocketTower(QPoint(SelBox->GetX() + 110, SelBox->GetY() + 112), QPoint(SelBox->GetX() + 95, SelBox->GetY() + 95), 76, 50));
                break;
            case 3: //星星塔
                if (canbuytower(320)) return;
                tower_list.push_back(new StarTower(QPoint(SelBox->GetX() + 110, SelBox->GetY() + 104), QPoint(SelBox->GetX() + 95, SelBox->GetY() + 95), 80, 70));
                break;
            default:
                break;
            }

            update();
            return;
        }
    for (auto APit : towerpit_list)
        if (MouClickRegion(APit->Getppos().x(), APit->GetWidth(), APit->Getppos().y(), APit->GetHeight()))
       {
             DisplayRange = false;
            for (auto defei : tower_list)      //遍历数组判断防御塔坐标和点击坑坐标重合则返回
                if(defei->Getupleftpos().x() == APit->Getppos().x() && defei->Getupleftpos().y() == APit->Getppos().y())
                {
                    DisplayRangeX = defei->Getupleftpos().x(), DisplayRangeY = defei->Getupleftpos().y();   //记录要显示攻击范围的防御塔的坐标
                     DisplayRange = true;
                     return;
                }
            SelBox->CheckTower(APit->Getppos().x(), APit->Getppos().y());  //选中防御塔，选择框显示
            update();
            return;
        }
    SelBox->SetDisplay(false);      //取消显示选择框

    update();
}

int MainWindow::distance(QPoint p1,QPoint p2){
    int x1=p1.x()-p2.x();
    int y1=p1.y()-p2.y();
    return abs(sqrt(x1*x1+y1*y1));
}
void MainWindow::addtowerpit(){
      towerpit_list.push_back(new TowerPit(QPoint(9*40,1*40)));
      towerpit_list.push_back(new TowerPit(QPoint(9*40,3*40)));
      towerpit_list.push_back(new TowerPit(QPoint(5*40,3*40)));
      towerpit_list.push_back(new TowerPit(QPoint(10*40,6*40)));
      towerpit_list.push_back(new TowerPit(QPoint(4*40,7*40)));
      towerpit_list.push_back(new TowerPit(QPoint(4*40,10*40)));
      towerpit_list.push_back(new TowerPit(QPoint(8*40,10*40)));
      towerpit_list.push_back(new TowerPit(QPoint(12*40,10*40)));
      towerpit_list.push_back(new TowerPit(QPoint(16*40,10*40)));
      towerpit_list.push_back(new TowerPit(QPoint(20*40,10*40)));
      towerpit_list.push_back(new TowerPit(QPoint(16*40,7*40)));
       home->setX(24*40), home->setY(8* 40);
}
//析构释放内存
MainWindow::~MainWindow()
{
    //释放防御塔坑指针数组
    for (auto it = tower_list.begin(); it != tower_list.end(); it++)
    {
        delete *it;
        *it = NULL;
    }

    //释放选择框类
    delete SelBox;
    SelBox = NULL;

    //释放防御塔父类指针数组
    for (auto it = tower_list.begin(); it != tower_list.end(); it++)
    {
        delete *it;
        *it = NULL;
    }

    //释放怪物数组
    for (auto it = enemy_list.begin(); it != enemy_list.end(); it++)
    {
        delete *it;
        *it = NULL;
    }

    //释放爆炸效果指针数组
    for (auto it = ExploEffectCoor.begin(); it != ExploEffectCoor.end(); it++)
    {
        delete *it;
        *it = NULL;
    }

    delete home;
 }
