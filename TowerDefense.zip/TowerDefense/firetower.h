#ifndef FIRETOWER_H
#define FIRETOWER_H

#include "towerparent.h"

//火炮塔类
class FireTower : public TowerParent
{
public:
    FireTower(QPoint pos,QPoint upleftpos, int Fwidth = 80, int Fheight = 80);
};

#endif // FIRETOWER_H
