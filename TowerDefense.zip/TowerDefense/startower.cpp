#include "startower.h"
#include<QPoint>
//星星防御塔类函数实现
//构造
StarTower::StarTower(QPoint pos, QPoint upleftpos,int wwidth, int hheight)
{

   _pos.setX(pos.x());
   _pos.setY(pos.y());
    B_sprite = QString(":/image/tower3.jpg");
    this->width = wwidth, this->height = hheight;
    _upleftpos.setX(upleftpos.x());
    _upleftpos.setY(upleftpos.y());
    this->Range = 280;    //射程
    this->BullPath = QString(":/image/Shells3.png");
    this->bullwidth = 40, this->bullheight = 40;           //子弹大小
    this->attack =90;    //攻击力
    this->ExplRangeWidth = 85;    //爆炸效果宽高
    this->ExplRangeHeight = ExplRangeWidth;
}
