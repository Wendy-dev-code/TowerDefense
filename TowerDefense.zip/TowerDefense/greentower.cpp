#include "greentower.h"

//绿色防御塔类函数实现
//构造
GreenTower::GreenTower(QPoint pos,QPoint upleftpos, int Fwidth, int Fheight)
{
    _pos.setX(pos.x());
    _pos.setY(pos.y());
    B_sprite= QString(":/image/tower1.jpg");
    width = Fwidth, height = Fheight;
    _upleftpos.setX(upleftpos.x());
    _upleftpos.setY(upleftpos.y());
    Range = 200;    //射程
    BullPath = QString(":/image/Shells0.png");
    bullwidth = 30, bullheight = 30;           //子弹大小
    attack = 40;    //攻击力
    ExplRangeWidth = 65;    //爆炸效果宽高
    ExplRangeHeight = ExplRangeWidth;
}
