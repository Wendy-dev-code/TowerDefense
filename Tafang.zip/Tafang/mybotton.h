#ifndef MYBOTTON_H
#define MYBOTTON_H
#include<QPushButton>
#include<QWidget>
#include<QPropertyAnimation>
#include<QAction>
class MyBotton:public QPushButton
{
   Q_OBJECT
public:
    MyBotton(QString pic);
    void zoomdown();
    void zoomup();
signals:
    void choosehello();
};

#endif // MYBOTTON_H
