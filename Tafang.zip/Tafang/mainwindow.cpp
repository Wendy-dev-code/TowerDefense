#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPixmap>
#include<iostream>
#include<QDebug>
#include<QPainter>
#include<QPushButton>
#include<QDebug>
#include"mybotton.h"
#include"mywindow.h"
#include<QTimer>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    this->setFixedSize(1000,600);
    ui->setupUi(this);
    MyBotton *btn =new MyBotton(":/button.png");
    btn->setParent(this);
    btn->move(40,40);
    MyWindow *scene=new MyWindow();
    connect(btn,&QPushButton::clicked,this,[=](){//=是可以使用当前类的所有东西，（）不用填什么，
        btn->zoomdown();
        btn->zoomup();
        QTimer::singleShot(500,this,[=](){
            this->hide();
            scene->show();
        });
    });
    connect(scene,&MyWindow::chooseBack,this,[=](){
            this->hide();
            scene->show();
            });
     /*
     QPushButton *bin=new QPushButton(this);
     bin->setFixedSize(100,50);
     bin->move(40,40);
     connect(bin,&QPushButton::clicked,this,&QMainWindow::close);*/

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *){//进入Mainwindow的话就会调用Paintevent函数
    //QPainter(QPaintDevice *device) 画家类指定一个绘图的设备
    //drawImage drawpixmap
    QPainter painter(this);//主窗口画
    QPixmap pixmap(":/TileC.jpg");
    painter.drawPixmap(0,0,1000,600,pixmap);
}


