#include "mybotton.h"
#include<QPixmap>
#include<QWidget>
#include<QString>
#include<QSize>
#include<QPropertyAnimation>
MyBotton::MyBotton(QString pic):QPushButton(0)
{
    QPixmap pixmap(pic);
    this->setFixedSize(pixmap.width(),pixmap.height());
    this->setStyleSheet("QPushButton{border:Opx;}");
    this->setIcon(pixmap);
    this->setIconSize(QSize(pixmap.width(),pixmap.height()));
    this->setContextMenuPolicy(Qt::ActionsContextMenu);
    QAction *action1=new QAction(this);
    action1->setText("SetTower");
    this->addAction(action1);//按钮的函数
   /* QAction *action2=new QAction(this);
    action2->setText("EraseTower");
    this->addAction(action2);*/
}
void MyBotton::zoomdown(){
    QPropertyAnimation * animation = new QPropertyAnimation(this,"geometry");
    animation->setDuration(200);
    animation->setStartValue(QRect(this->x(),this->y(),this->width(),this->height()));
    animation->setEndValue(QRect(this->x(),this->y()+10,this->width(),this->height()));
    animation->setEasingCurve(QEasingCurve::OutBounce);
    animation->start();
}
void MyBotton::zoomup(){
    QPropertyAnimation * animation = new QPropertyAnimation(this,"geometry");
    animation->setDuration(200);
    animation->setStartValue(QRect(this->x(),this->y()+10,this->width(),this->height()));
    animation->setEndValue(QRect(this->x(),this->y(),this->width(),this->height()));
    animation->setEasingCurve(QEasingCurve::OutBounce);
    animation->start();
}
