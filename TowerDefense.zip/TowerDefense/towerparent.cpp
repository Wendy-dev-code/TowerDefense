#include "towerparent.h"

QPoint TowerParent::Getpos() const{
    return _pos;
}

int TowerParent::GetWidth() const //获取宽
{
    return width;
}

int TowerParent::GetHeight() const //获取高
{
    return height;
}

/*int TowerParent::GetRotatAngle() const//获取旋转角度
{
    return RotatAngle;
}*/

QString TowerParent::GetImgPath() const  //获取图片
{
    return B_sprite;
}
QPoint TowerParent::Getupleftpos() const{
    return _upleftpos;
}
int TowerParent::GetRange() const           //获取防御塔射程
{
    return Range;
}

Enemy* TowerParent::GetAimsMonster() const //返回当前防御塔的目标怪物
{
    return aimsmon;
}

void TowerParent::SetAimsMonster(Enemy* mon)  //设置当前防御塔的目标怪物
{
    aimsmon = mon;
}

QString TowerParent::GetBulletPath() const      //返回防御塔子弹图片路径
{
    return BullPath;
}

QVector<BulletStr*>& TowerParent::GetBulletVec()//返回子弹数组
{
    return BulletVec;
}

void TowerParent::InterBullet()     //新建子弹函数
{
    counter++;

    if(counter < 7 || !aimsmon)      //计数器到达一定数值且目标怪物不为空时
        return;

    //向子弹数组中插入子弹
    BulletStr *bull = new BulletStr(QPoint(_upleftpos.x() + 40, _upleftpos.y()+40));

    bull->bullpos.setX(_upleftpos.x() + 40), bull->bullpos.setY(_upleftpos.y() +40);

    //计算每一个子弹的路径
    if((!(aimsmon->Getmpos().x() - bull->bullpos.x())))   //除数为0或时不创建子弹
    {
        delete bull;
        bull = NULL;
        goto L1;
    }

    bull->k = (aimsmon->Getmpos().y() - bull->bullpos.y()) / (aimsmon->Getmpos().x() - bull->bullpos.x());
    bull->b = aimsmon->Getmpos().y() - aimsmon->Getmpos().x() * bull->k;

    bull->bullpos.setX(_upleftpos.x() +40), bull->bullpos.setY(_upleftpos.y() + 40);

    BulletVec.push_back(bull);              //将子弹插入到子弹数组当中

    if(aimsmon->Getmpos().x() <= _upleftpos.x() + 40)     //确定子弹的移动方向
        bull->dirflag = true;
    L1:

    counter = 0;    //计数器重置为0

}

void TowerParent::BulletMove()         //子弹移动函数
{
    //子弹移动
    for(auto bulli : BulletVec)
    {
        const int speed = 20;              //子弹移动速度，每一次刷新画面移动的像素距离，这个值可以随意

        //子弹的移动方向为左则子弹x坐标每次-=，反之+=
        bulli->dirflag ? bulli->bullpos.setX(bulli->bullpos.x()-speed) : bulli->bullpos.setX(bulli->bullpos.x()+speed);

        bulli->bullpos.setY( bulli->k* bulli->bullpos.x() + bulli->b);    //子弹纵坐标改变
    }

    for(auto bullit = BulletVec.begin(); bullit != BulletVec.end(); bullit++)         //遍历删除越界子弹
        if((*bullit)->bullpos.x()>1040 || (*bullit)->bullpos.x()< 0 || (*bullit)->bullpos.y() > 640 || (*bullit)->bullpos.y() < 0)
        {
            delete bullit;
            BulletVec.erase(bullit);
            break;
        }
}

int TowerParent::GetBulletWidth() const //获取子弹的宽度
{
    return bullwidth;
}

int TowerParent::GetBulletHeight() const//获取子弹的宽度
{
    return bullheight;
}

int TowerParent::GetAttack() const      //获取防御塔攻击力
{
    return attack;
}

void TowerParent::SetAttack(int attack)       //设置防御塔攻击力
{
    this->attack = attack;
}

void TowerParent::SetWidthHeight(int width, int height)  //设置防御塔宽高
{
    this->width = width, this->height = height;
}

void TowerParent::Setpos(QPoint pos)       //设置坐标
{
    this->_pos.setX(pos.x());
    this->_pos.setY(pos.y());
}


void TowerParent::SetExplRangeWidthHeight(int width, int height)     //设置防御塔对应的爆炸效果的宽高
{
    ExplRangeWidth = width, ExplRangeHeight = height;
}

void TowerParent::SetBulletWidthHeight(int width, int height)         //设置子弹宽高
{
    bullwidth = width, bullheight = height;
}

int& TowerParent::SetRange()                //设置防御塔的攻击范围
{
    return Range;
}

int TowerParent::GetExplRangeWidth() const      //获取爆炸效果宽
{
    return ExplRangeWidth;
}

int TowerParent::GetExplRangeHeight() const     //获取爆炸效果高
{
    return ExplRangeHeight;
}








