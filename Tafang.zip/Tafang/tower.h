#ifndef TOWER_H
#define TOWER_H
#include<QObject>
#include<QPoint>
#include<QPixmap>
class Tower:public QObject
{
    Q_OBJECT
public:
    Tower(QPoint pot,QString pixFileName);
    void draw(QPainter * painter);
private:
    QPoint _pos;
    QPixmap pixmap;

};

#endif // TOWER_H
