#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QPainter>
#include <QMouseEvent>
#include <QTimer>
#include "towerpit.h"
#include "selectionbox.h"
#include "towerparent.h"
#include "Enemy.h"
#include <QLabel>
#include<QPoint>
class MainWindow : public QWidget
{
public:
    MainWindow();            //构造
    ~MainWindow();
    bool canbuytower(int money);         //判断能否买塔
    void paintEvent(QPaintEvent *);         //绘图事件
    void mousePressEvent(QMouseEvent *);    //鼠标点击事件
    void DrawSelectionBox(QPainter&);       //用于画出选择框
    void DrawDefenseTower(QPainter&);       //画出防御塔
    void DrawMonster(QPainter&);            //画出敌人
    void Drawupgrade(QPainter&);           //升级
    void DrawExplosion(QPainter&);          //画出爆炸效果
     void monstermove(QPoint**, QPoint, int);
protected:
    QVector<TowerPit*> towerpit_list;
    SelectionBox* SelBox = new SelectionBox(":/image/SelectionBox.png");
    QVector<TowerParent*> tower_list;
    QVector<Enemy*> enemy_list;
    int DisplayRangeX,DisplayRangeY;       //用于记录显示范围的防御塔的坐标
    bool DisplayRange = false;              //用于显示防御塔攻击范围
    QVector<ExploStr*> ExploEffectCoor;      //爆炸效果坐标数组
    int money = 1000;   //记录金钱
    QLabel *moneylb = new QLabel(this);   //显示金钱标签控件
    int life = 12;      //生命数量
    int counter = 0;    //用于产生怪物的计数器
    const int RewardMoney = 30; //每次击败怪物获得的金钱数量
    QPoint *home = new QPoint(0, 0);

    int distance(QPoint p1,QPoint p2);
    void addtowerpit();
    bool gamewin=false;
    bool gameend=false;

};

#endif  //MAINWINDOW_H
