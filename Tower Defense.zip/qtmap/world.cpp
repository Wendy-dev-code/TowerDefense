#include "world.h"
#include "icon.h"
#include "rpgobj.h"
#include <QMediaPlayer>
#include<iostream>
using namespace std;

World::~World(){
    delete this->_enemy;
}

void World::initWorld(string mapFile){
    //TODO ���������Ӧ�ø�Ϊ�ӵ�ͼ�ļ�װ��
    //player 5 5
    this->_enemy->initObj("enemy");
    this->_enemy->setPosX(12);
    this->_enemy->setPosY(5);

    RPGObj *p1 = new Fruit;
    p1->initObj("fruit");
    p1->setPosX(27);
    p1->setPosY(5);
    this->_objs.push_back(p1);
    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl("qrc:/sounds/hdl.mp3"));
    player->setVolume(30);
    player->play();
}

void World::show(QPainter * painter){
    QImage image(":/pics/TileA.png");
    painter->drawImage(0,0,image);
    int n = this->_objs.size();
    for (int i=0;i<n;i++){
        this->_objs[i]->show(painter);
    }
    this->_enemy->show(painter);



}

void World::eraseObj(int x, int y){
    vector<RPGObj*>::iterator it;
    it = _objs.begin();
    while(it!=_objs.end()){
        int flag1 = ((*it)->getObjType()!="stone"); //����ʯͷ
        int flag2 = ((*it)->getPosX() == x) && ((*it)->getPosY()==y);//λ���ص�

        if (flag1 && flag2){
            cout<<(*it)->getObjType()<<endl;
            (*it)->onErase();
            delete (*it);
            it = this->_objs.erase(it);
            break;
         }
        else{
            it++;
        }
    }

}

void World::handlePlayerMove(int direction, int steps){
    int x =  this->_enemy->getNextX(direction);
    int y = this->_enemy->getNextY(direction);
    this->eraseObj(x,y);
    this->_enemy->move(direction, steps);
}

