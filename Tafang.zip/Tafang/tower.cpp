#include "tower.h"
#include<QObject>
#include<QPixmap>
#include<QPainter>
Tower::Tower(QPoint pot,QString pixFileName):QObject(0),pixmap(pixFileName)
{
    _pos=pot;
}
void Tower::draw(QPainter *painter){
    painter->drawPixmap(_pos,pixmap);
}
