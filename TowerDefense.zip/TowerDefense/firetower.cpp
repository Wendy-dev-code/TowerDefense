#include "firetower.h"
#include<QPoint>
//火防御塔类函数实现
//构造
FireTower::FireTower(QPoint pos,QPoint upleftpos,  int Fwidth, int Fheight)
{
    //初始化成员变量，这里不能用初始化列表
    _pos.setX(pos.x());
    _pos.setY(pos.y());
    B_sprite = QString(":/image/tower4.jpg");
    width = Fwidth, height = Fheight;
    _upleftpos.setX(upleftpos.x());
    _upleftpos.setY(upleftpos.y());
    Range = 170;    //射程
    BullPath = QString(":/image/Shells1.png");
    bullwidth = 40, bullheight = 40;           //子弹大小
    attack = 55;    //攻击力
    ExplRangeWidth = 70;    //爆炸效果宽高
    ExplRangeHeight = ExplRangeWidth;
}
