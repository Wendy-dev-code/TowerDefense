#ifndef STARTOWER_H
#define STARTOWER_H

#include "towerparent.h"

//星星防御塔类
class StarTower : public TowerParent
{
public:
    StarTower(QPoint pos, QPoint upleftpos, int wwidth = 80, int hheight = 80);
};

#endif // STARTOWER_H
