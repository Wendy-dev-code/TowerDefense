#ifndef GLOBALSTRUCT_H
#define GLOBALSTRUCT_H

#include <QString>
#include<QPoint>
//选择框子按钮结构
struct Subbtn
{
    int SubX;           //子按钮相对选择框的横坐标
    int SubY;           //纵坐标
    int SubWidth = 56;  //子按钮宽
    int SubHeight = 56; //高
    QString SubImgPath; //子按钮的图片路径
};

//子弹结构
struct BulletStr
{
    QPoint bullpos;       //子弹坐标
    int k = 0, b = 0;   //用于计算出子弹路径函数
    bool dirflag = false;   //移动方向标识

    BulletStr(QPoint bulpos) : bullpos(bulpos) {}

    int GetX()  const
    {
        return bullpos.x();
    }

    int GetY() const
    {
        return bullpos.y();
    }
};
struct ExploStr     //爆炸效果结构
{
    QPoint pos;   //记录爆炸效果的坐标
    int index = 1;  //记录要显示的图片文件的序号

    int ExplRangeWidth;    //爆炸效果宽高
    int ExplRangeHeight;
    //爆炸效果需要初始化坐标、效果宽高
    ExploStr(QPoint ppos, int width, int height) : pos(ppos), ExplRangeWidth(width), ExplRangeHeight(height) {}
};

#endif // GLOBALSTRUCT_H
