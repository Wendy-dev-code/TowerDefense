#ifndef ROCKETTOWER_H
#define ROCKETTOWER_H

#include "towerparent.h"
//光炮类
class RocketTower : public TowerParent
{
public:
    RocketTower(QPoint pos,QPoint upleftpos, int Fwidth = 80, int Fheight = 80);
};

#endif // ROCKETTOWER_H
