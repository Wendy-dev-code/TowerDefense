#include "object.h"
#include<QPixmap>
Object::Object(QPoint startpos, QPoint targetpos, QString filename):QObject(0),pixmap(filename){
    this->currentpos=startpos;
    this->startpos=startpos;
    this->targetpos=targetpos;
}
void Object::draw(QPainter *painter){
    painter->drawPixmap(currentpos,pixmap);
}
void Object::move(){
    QPropertyAnimation * animation= new QPropertyAnimation(this,"currentpos");
    animation->setDuration(2000);
    animation->setStartValue(startpos);
    animation->setEndValue(targetpos);
    animation->start();
}
QPoint Object::getCurrentpos(){
    return this->currentpos;
}
void Object::setCurrentpos(QPoint pos){
    this->currentpos=pos;
}
