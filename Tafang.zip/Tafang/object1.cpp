#include "object1.h"
#include<QPoint>
#include<QVector2D>
#include<QTimer>
#include <QMediaPlayer>
Object1::Object1(QPoint startpos, QPoint targetpos, QString filename):QObject(0),pixmap(filename){
    this->currentpos=startpos;
    this->startpos=startpos;
    this->targetpos=targetpos;
    speed=1.0;/*
    QTimer *timer=new QTimer(this);
    connect(timer,&QTimer::timeout,this,speed++);//每10秒更新一次
            timer->start(10);*/

}
void Object1::move(){
    QVector2D vector(targetpos-startpos);
    vector.normalize();
    currentpos=currentpos+vector.toPoint()*speed;
   /* if(targetpos==currentpos){
        this->onErase();
    }*/
}
void Object1::draw(QPainter *painter){
    painter->drawPixmap(currentpos,pixmap);
}
/*void Object1::onErase(){
    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl(":/erase.mp3"));
    player->setVolume(30);
    player->play();
}
*/
