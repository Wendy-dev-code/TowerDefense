#ifndef TOWER_H
#define TOWER_H
#include<QPoint>
#include "rpgobj.h"
#include<QPixmap>
#include<QObject>
class tower:public QObject
{
    Q_OBJECT
public:
    tower(QPoint pos,QString mapname);
    void draw(QPainter *painter);
private:
    QPoint _pos;
    QPixmap pixmap;
};

#endif // TOWER_H
