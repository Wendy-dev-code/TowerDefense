#ifndef DEFENSETOWERPIT_H
#define DEFENSETOWERPIT_H

#include <QVector>
#include<QPoint>
//防御塔坑类
class TowerPit
{
private:
    QPoint ppos;           //位置坐标
    int mwidth, mheight;  //宽高

public:
    TowerPit(QPoint pos, int width = 80, int height = 80);
    QPoint Getppos();
    int GetWidth(); //获取宽
    int GetHeight();//获取高
};

#endif // DEFENSETOWERPIT_H
