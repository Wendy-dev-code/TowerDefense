#include "towerpit.h"
#include<QPoint>
//构造
TowerPit::TowerPit(QPoint pos, int width, int height)
    :ppos(pos) ,mwidth(width), mheight(height) {}

QPoint TowerPit::Getppos() {
    return ppos;
}

int TowerPit::GetWidth()//获取宽
{
    return mwidth;
}

int TowerPit::GetHeight()//获取高
{
    return mheight;
}

