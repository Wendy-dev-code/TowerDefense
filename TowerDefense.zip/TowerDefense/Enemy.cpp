#include "Enemy.h"
#include <QDebug>

//怪物类函
Enemy::Enemy(QPoint **pointarr, int length, QPoint mpos, int fid) :
    m_pos(mpos), m_id(fid)
{
    for(int i = 0; i < length; i++)      //将传进来的数组插入到Waypoint动态数组
        Waypoint.push_back(pointarr[i]);
    //确定不同怪物的生命值
    switch (m_id)
    {
    case 1:
        m_health = 350;   //生命值
        mwidth = 80, mheight = 80;  //宽高
        mspeed=10;
        m_sprite= ":/image/enemy1.jpg";
        break;
    case 2:
        m_health = 500;
        mwidth = 80, mheight = 80;
        mspeed=10;
        m_sprite = ":/image/enemy2.png";
        break;
    default:
        break;
    }
}

//怪物按设定路径点移动
bool Enemy::Move()
{
    if(Waypoint.empty())
        return true;

    //如果第一个路径点的y小于怪物原本的路径点，则怪物向下走
    if (Waypoint.at(0)->y() >m_pos.y()) //下
    {
        m_pos.setY(m_pos.y() +mspeed);
        return false;
    }

    if (Waypoint.at(0)->x()<m_pos.x()) //左
    {
         m_pos.setX(m_pos.x() -mspeed);
        return false;
    }

    if (Waypoint.at(0)->x()> m_pos.x()) //右
    {
        m_pos.setX(m_pos.x() +mspeed);
        return false;
    }

    if (Waypoint.at(0)->y() < m_pos.y()) //上
    {
        m_pos.setY(m_pos.y() -mspeed);
        return false;
    }

    //如果怪物的坐标和路径点坐标几乎重合，则删除这个路径点
    if (Waypoint.at(0)->y() == m_pos.y() && Waypoint.at(0)->x() ==m_pos.x())
    {
        Waypoint.erase(Waypoint.begin());       //从数组中删除
    }

    return false;
}


QPoint Enemy::Getmpos(){
    return m_pos;
}

QString Enemy::GetImgPath() const //获取图片路径
{
    return m_sprite;
}

int Enemy::GetId() const      //获取编号
{
    return m_id;
}

int Enemy::GetHealth() const  //获取生命值
{
    return m_health;
}

void Enemy::SetHealth(int health)//设置生命值
{
    m_health = health;
}
int Enemy::GetWidth() const   //获取宽
{
    return mwidth;
}
int Enemy::GetHeight() const  //获取高
{
    return mheight;
}


