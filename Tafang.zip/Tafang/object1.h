#ifndef OBJECT1_H
#define OBJECT1_H
#include<QPoint>
#include<QPixmap>
#include<QPainter>
#include<QPropertyAnimation>
#include<QObject>
#include <QMediaPlayer>
class Object1:public QObject
{
    Q_OBJECT
public:
    Object1(QPoint startpos,QPoint targetpos,QString filename);
    void move();
    void draw(QPainter *painter);
    //void onErase();
private:
    QPoint startpos;
    QPoint targetpos;
    QPoint currentpos;
    QPixmap pixmap;
    double speed;
signals:
};

#endif // OBJECT1_H
