#ifndef ENEMY_H
#define ENEMY_H

#include <QVector>
#include <QString>
#include "struct.h"
#include<QPoint>
class Enemy
{
public:
    Enemy(QPoint **waypoint, int length,QPoint mpos, int fid);  //构造
    bool Move();            //怪物移动函数
    QPoint Getmpos();
    int GetWidth() const;   //获取宽
    int GetHeight() const;  //获取高
    QString GetImgPath() const; //获取图片路径
    int GetId() const;      //获取编号
    int GetHealth() const;  //获取生命值
    void SetHealth(int);    //设置生命值
protected:
    QVector<QPoint*> Waypoint;  //存储怪物路径点数组
    QPoint m_pos;                  //怪物坐标
    int mwidth, mheight;         //怪物宽高
    QString m_sprite;             //怪物图片路径
    int m_id;                      //怪物编号
    int m_health;                  //怪物生命值
    int mspeed = 10;
};

#endif // ENEMY_H
